import pygame
import math
import pymunk
import pymunk.autogeometry
from chunk import chunks
from constants import BLOCK_SIZE, CHUNK_WIDTH
import random

def rotate_point(x, y, angle):
    cos_angle = math.cos(angle)
    sin_angle = math.sin(angle)
    new_x = cos_angle * x - sin_angle * y
    new_y = sin_angle * x + cos_angle * y
    return new_x, new_y

def rotate_vertices(vertices, angle):
        rotated_vertices = []
        for vertex in vertices:
            rotated_x, rotated_y = rotate_point(vertex[0] - BLOCK_SIZE / 2 , vertex[1] - BLOCK_SIZE / 2, angle)
            rotated_vertices.append((rotated_x, rotated_y))
        return rotated_vertices

class Pickaxe:
    def __init__(self, space, x, y, texture, sound_manager, damage=10, velocity=0, rotation=0, mass=100):
        self.texture = texture
        self.velocity = velocity
        self.rotation = rotation
        self.space = space
        self.damage = damage # Default damage increased
        self.is_enlarged = False

        vertices = rotate_vertices([(0, 0), (10, 0), (110, 100), (100, 110), (0, 10), (110, 110)], -math.pi / 2)
        vertices2 = rotate_vertices([(110, 30), (120, 40), (120, 90), (100, 90), (100, 40), (110, 100)], -math.pi / 2)
        vertices3 = rotate_vertices([(30, 110), (40, 120), (90, 120), (40, 100), (90, 100), (100, 110)], -math.pi / 2)

        inertia = pymunk.moment_for_poly(mass, vertices)
        self.body = pymunk.Body(mass, inertia)
        self.body.position = (x, y)
        self.body.angle = math.radians(rotation)

        self.sound_manager = sound_manager

        self.shapes = []
        for vertices in [vertices, vertices2, vertices3]:
            shape = pymunk.Poly(self.body, vertices)
            shape.elasticity = 0.7
            shape.friction = 0.7
            shape.collision_type = 1 
            self.shapes.append(shape)

        self.space.add(self.body, *self.shapes)

        handler = space.add_collision_handler(1, 2)  
        handler.post_solve = self.on_collision

    def on_collision(self, arbiter, space, data):
        block_shape = arbiter.shapes[1]  
        block = block_shape.block_ref  

        block.first_hit_time = pygame.time.get_ticks()  
        block.last_heal_time = block.first_hit_time

        block.hp -= self.damage  

        if (block.name == "grass_block" or block.name == "dirt"):
            self.sound_manager.play_sound("grass" + str(random.randint(1, 4)))
        else:
            self.sound_manager.play_sound("stone" + str(random.randint(1, 4)))

        self.body.angle += random.choice([0.01, -0.01])

    def random_pickaxe(self, texture_atlas, atlas_items): 
        pickaxe_name = random.choice(list(atlas_items["pickaxe"].keys()))
        self.texture = texture_atlas.subsurface(atlas_items["pickaxe"][pickaxe_name])
        print("Setting pickaxe to:", pickaxe_name)

        if self.is_enlarged:
            new_size = (BLOCK_SIZE * 3, BLOCK_SIZE * 3)
            self.texture = pygame.transform.scale(self.texture, new_size)

        # Damage multiplied by 5 for super fast mining!
        if(pickaxe_name =="wooden_pickaxe"):  
            self.damage = 10
        elif(pickaxe_name =="stone_pickaxe"):
            self.damage = 20
        elif(pickaxe_name =="iron_pickaxe"):
            self.damage = 30
        elif(pickaxe_name =="golden_pickaxe"):
            self.damage = 40
        elif(pickaxe_name =="diamond_pickaxe"):
            self.damage = 50
        elif(pickaxe_name =="netherite_pickaxe"):
            self.damage = 60

    def pickaxe(self, name, texture_atlas, atlas_items):
        self.texture = texture_atlas.subsurface(atlas_items["pickaxe"][name])
        print("Setting pickaxe to:", name)

        if self.is_enlarged:
            new_size = (BLOCK_SIZE * 3, BLOCK_SIZE * 3)
            self.texture = pygame.transform.scale(self.texture, new_size)

        # Damage multiplied by 5 for super fast mining!
        if(name =="wooden_pickaxe"):  
            self.damage = 10
        elif(name =="stone_pickaxe"):
            self.damage = 20
        elif(name =="iron_pickaxe"):
            self.damage = 30
        elif(name =="golden_pickaxe"):
            self.damage = 40
        elif(name =="diamond_pickaxe"):
            self.damage = 50
        elif(name =="netherite_pickaxe"):
            self.damage = 60

    def update(self):
        # Increased Terminal Velocity from 1000 to 3500
        if self.body.velocity.y > 3500:
            self.body.velocity = (self.body.velocity.x, 3500)

        all_vertices = []
        for shape in self.shapes:
            for v in shape.get_vertices():
                world_v = self.body.local_to_world(v)
                all_vertices.append(world_v)

        min_x = min(v.x for v in all_vertices)
        max_x = max(v.x for v in all_vertices)

        left_limit = BLOCK_SIZE
        right_limit = BLOCK_SIZE * (CHUNK_WIDTH - 1)

        if min_x < left_limit:
            dx = left_limit - min_x
            self.body.position = (self.body.position.x + dx, self.body.position.y)

        if max_x > right_limit:
            dx = max_x - right_limit
            self.body.position = (self.body.position.x - dx, self.body.position.y)

        if hasattr(self, "enlarge_end_time") and pygame.time.get_ticks() > self.enlarge_end_time:
            self.reset_size()
            self.is_enlarged = False

    def draw(self, screen, camera):
        rotated_image = pygame.transform.rotate(self.texture, -math.degrees(self.body.angle))  
        rect = rotated_image.get_rect(center=(self.body.position.x, self.body.position.y))
        rect.y -= camera.offset_y
        rect.x -= camera.offset_x
        screen.blit(rotated_image, rect)

    def enlarge(self, duration=5000):
        print("Enlarging pickaxe")
        if hasattr(self, "is_enlarged") and self.is_enlarged:
            self.enlarge_end_time += duration
            return

        self.original_texture = self.texture.copy()
        self.original_shapes = self.shapes[:]  
        self.is_enlarged = True

        new_size = (BLOCK_SIZE * 3, BLOCK_SIZE * 3)
        self.texture = pygame.transform.scale(self.original_texture, new_size)

        self.space.remove(*self.shapes)  
        new_shapes = []
        for shape in self.original_shapes:
            scaled_vertices = [(x * 3, y * 3) for x, y in shape.get_vertices()]
            new_shape = pymunk.Poly(self.body, scaled_vertices)
            new_shape.elasticity = shape.elasticity
            new_shape.friction = shape.friction
            new_shape.collision_type = shape.collision_type
            new_shapes.append(new_shape)
        self.shapes = new_shapes
        self.space.add(*self.shapes)  

        self.enlarge_end_time = pygame.time.get_ticks() + duration

    def reset_size(self):
        if hasattr(self, "original_shapes"):
            self.texture = self.original_texture.copy()
            self.space.remove(*self.shapes)
            self.shapes = self.original_shapes[:]
            self.space.add(*self.shapes)
            self.is_enlarged = False
            del self.enlarge_end_time
